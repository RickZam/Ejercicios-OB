package ejercicio3;

import java.util.Vector;

public class vector {

    public static void main(String[] args) {

        Vector<String> vector= new Vector<>(5);

        vector.add("Maria");
        vector.add("Juan");
        vector.add("Claudia");
        vector.add("Jose");
        vector.add("Ivan");

        vector.remove(2);
        vector.remove(2);

        System.out.println(vector);

    }
}
