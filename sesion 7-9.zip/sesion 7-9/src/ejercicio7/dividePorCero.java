package ejercicio7;

public class dividePorCero {

    public static void main(String[] args) {

        try {int a = 3/0;}

        catch (ArithmeticException e){

            System.out.println("Esto no puede hacerse");
        }
        finally{

        System.out.println("Demo de código");


    }


    }
}
