package ejercicio1;

public class arrayUnidimensional {
    public static void main(String[] args) {
        String[] frutas = {"manzana", "pera", "limon", "naranja"};

        for (String fruta:frutas){
            System.out.println(fruta);
        }
    }
}

