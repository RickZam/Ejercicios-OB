package ejercicio8;

import java.io.*;
import java.io.FileInputStream;



public class inputStream {

    public static void main(String[] args) {

        try{InputStream fileIn = new FileInputStream("C:\\Program Files\\JetBrains\\IntelliJ IDEA Community Edition 2022.3.2\\prueba.txt");

            byte[] datos = fileIn.readAllBytes();

            PrintStream fileOut = new PrintStream("C:\\Program Files\\JetBrains\\IntelliJ IDEA Community Edition 2022.3.2\\prueba2.txt");

            fileOut.write(datos);
        }

        catch (FileNotFoundException e) {
            System.out.println("El programa da error: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("El programa da error: " + e.getMessage());
        }


    }
}
