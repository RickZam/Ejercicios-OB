package ejercicio5;

import java.util.ArrayList;
import java.util.LinkedList;

public class arrayList {

    public static void main(String[] args) {

    ArrayList<String> dispositivos = new ArrayList<>();

    dispositivos.add("movil");
    dispositivos.add("pc");
    dispositivos.add("tablet");
    dispositivos.add("tv");


    LinkedList<String> dispositivosCopia = new LinkedList<>(dispositivos);

        System.out.println(dispositivosCopia);
}
    }