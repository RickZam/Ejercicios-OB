package ejercicio6;

import java.util.ArrayList;

public class arrayList2 {

    public static void main(String[] args) {

        ArrayList<Integer> notas = new ArrayList<>();



        for(int i=0; i<10; i++) {
            notas.add(i);


            }

        for(int j=0; j<10; j++) {
            if(notas.get(j) % 2 == 0){
                notas.remove(notas.get(j));



        }
            System.out.println(notas);

        }

    }
}

