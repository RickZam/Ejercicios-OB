package ejercicio2;

public class arrayBidimensional {
    public static void main(String[] args) {

        int [][] edad = new int [2] [2];

        edad [0][0] = 11;
        edad [0][1] = 22;
        edad [1][0] = 33;
        edad [1][1] = 44;

        for (int i = 0; i< edad.length; i++){
            System.out.println("El valor de i: " + i);

            for (int j = 0; j<edad[i].length; j++) {
                System.out.println("La posición es: i " + i + ", j = " + j);
                System.out.println("El valor de la posición es: " + edad[i][j]);

            }
        }
    }
}
