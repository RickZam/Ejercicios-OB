package ejercicio4;

import java.util.Vector;

public class problemaVector {

    public static void main(String[] args) {


        Vector<Integer> notas = new Vector<>(4); // En este caso, la memoria sólo puede albergar 4 notas, si metemos más, automáticamente se duplicará
                                                            //  hasta dar cabida a todas las notas apuntadas (en este caso 5). Si el caso fuese 1000 notas, la
                                                            //  memoria debería duplicarse demasiadas veces, consumiendo así mas recursos y enlenteciendo el programa.

        notas.add(4);
        notas.add(5);
        notas.add(9);
        notas.add(10);
        notas.add(2);

        System.out.println(notas);
    }
}
