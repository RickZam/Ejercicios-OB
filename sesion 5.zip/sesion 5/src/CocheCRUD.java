
public interface CocheCRUD {


    public static void save(CocheCRUD cocheCRUD){

        System.out.println("save");


    }

    public static void findAll(CocheCRUD cocheCrud){

        System.out.println("findAll");
    }

    public static void delete(CocheCRUD cocheCRUD){

        System.out.println("delete");
    }
    }






