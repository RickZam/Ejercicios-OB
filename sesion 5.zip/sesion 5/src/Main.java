public class Main {
    public static void main(String[] args) {

        CocheCRUD cocheCrud = new CocheCRUDImpl();

        CocheCRUD.save(cocheCrud);

        CocheCRUD.findAll(cocheCrud);

        CocheCRUD.delete(cocheCrud);

        System.out.println(cocheCrud);
    }
}