public class CocheCRUDImpl implements CocheCRUD {

    String marca;

    int puertas;

    boolean deportivo;

    public CocheCRUDImpl(){}

    public CocheCRUDImpl(String marca, int puertas, boolean deportivo){

        this.marca =marca;
        this.puertas=puertas;
        this.deportivo=deportivo;

    }


    @Override
    public String toString() {
        return "CocheCRUDImpl{" +
                "marca='" + marca + '\'' +
                ", puertas=" + puertas +
                ", deportivo=" + deportivo +
                '}';
    }
}
