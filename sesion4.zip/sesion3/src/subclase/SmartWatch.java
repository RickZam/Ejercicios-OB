package subclase;

import superclase.SmartDevice;

public class SmartWatch extends SmartDevice {

    public int autonomia;


    public SmartWatch(){
    }
    public SmartWatch(String pantalla, String tipoConexion, int memoria, boolean tactil, int autonomia) {

        super(pantalla, tipoConexion, memoria, tactil);
        this.autonomia=autonomia;

    }



}
