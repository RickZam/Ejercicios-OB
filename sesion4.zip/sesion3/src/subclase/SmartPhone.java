package subclase;

import superclase.SmartDevice;

public class SmartPhone extends SmartDevice {

     public String marca;

    public SmartPhone(){
    }
    public SmartPhone(String pantalla, String tipoConexion, int memoria, boolean tactil, String marca) {

        super(pantalla, tipoConexion, memoria, tactil);
        this.marca=marca;
    }
}
