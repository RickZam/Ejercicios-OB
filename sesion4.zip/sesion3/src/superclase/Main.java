package superclase;

import subclase.SmartPhone;

import subclase.SmartWatch;

import superclase.SmartDevice;



public class Main {

    public static void main(String[] args) {


        SmartPhone iphone= new SmartPhone ("AMOLED", "Wi-Fi", 256, true, "Apple");

        System.out.println("Caracteristicas del terminal: " + iphone.pantalla + " " + iphone.tipoConexion + " " + iphone.memoria + " " + iphone.tactil + " " + iphone.marca);


        SmartWatch appleWatch= new SmartWatch ("LED", "Bluetooth", 148, true, 40);

        System.out.println("Caracteristicas del dispositivo: " + appleWatch.pantalla + " " + appleWatch.tipoConexion + " " + appleWatch.memoria + " " + appleWatch.tactil + " " + appleWatch.autonomia);
    }

}