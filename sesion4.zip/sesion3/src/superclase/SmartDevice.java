package superclase;

public class SmartDevice {


    protected String pantalla;
    protected String tipoConexion;
    protected int memoria;
    protected boolean tactil;

    public SmartDevice(String pantalla, String tipoConexion, int memoria, boolean tactil) {

        this.pantalla=pantalla;
        this.tipoConexion=tipoConexion;
        this.memoria = memoria;
        this.tactil=tactil;

    }

    public SmartDevice() {
    }

    public void anoProduccion () {

    }
}

